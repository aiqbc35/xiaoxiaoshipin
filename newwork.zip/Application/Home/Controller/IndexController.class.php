<?php
namespace Home\Controller;
use Think\Controller;
use Home\Model\VideoModel;

class IndexController extends Controller {

	$this->show('this is home');


}