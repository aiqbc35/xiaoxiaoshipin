<?php
namespace Home\Model;
use Think\Model\ViewModel;
class VideoViewModel extends ViewModel {
   public $viewFields = array(
     'video'=>array('id','name','image','link','hit','addtime','sort','service','_type'=>'left'),
     'service'=>array('link'=>'server','_on'=>'video.service=service.name'),
   );
 }